// ----- attaque.h -----
#ifndef ATTAQUE_H
#define ATTAQUE_H

#include "data.h"  // À adapter selon où tu déclares Combattant

void attaque_classique(Combattant *attaquant, Combattant *cible);

#endif
