#ifndef SELECTION_H
#define SELECTION_H

#include "equipe.h"
#include "personnage.h"

// Fonction pour faire choisir les personnages pour une Ã©quipe
void selectionner_personnages(Equipe* equipe);

#endif