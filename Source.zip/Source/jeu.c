#include "attaque.h"
#include "data.h"
#include "interface.h"
#include "logic.h"



#include <time.h>
#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
