#include "fighter.h"

// === Chargement ===
void afficher_chargement(SDL_Renderer *rendu) {
    SDL_Surface *image_fond = IMG_Load("ressource/image/Chargement.png");
    SDL_Texture *fond = SDL_CreateTextureFromSurface(rendu, image_fond);
    SDL_FreeSurface(image_fond);

    TTF_Font *police = TTF_OpenFont("ressource/langue/police/arial.ttf", 28);
    TTF_Font *police_grasse = TTF_OpenFont("ressource/langue/police/arial.ttf", 34);
    SDL_Color blanc = {255, 255, 255, 255};

    SDL_Rect zone_barre = {60, 550, 900, 30};
    SDL_Rect zone_texte = {zone_barre.x, zone_barre.y - 50, 400, 30};

    SDL_Surface *surf_texte = TTF_RenderUTF8_Blended(police, "Chargement en cours...", blanc);
    SDL_Texture *texture_texte = SDL_CreateTextureFromSurface(rendu, surf_texte);
    SDL_FreeSurface(surf_texte);

    int nb_blocs = 50, marge = 2;
    int largeur_bloc = (zone_barre.w - (nb_blocs - 1) * marge) / nb_blocs;

    for (int i = 0; i <= nb_blocs; i++) {
        SDL_RenderClear(rendu);
        SDL_RenderCopy(rendu, fond, NULL, NULL);
        SDL_RenderCopy(rendu, texture_texte, NULL, &zone_texte);

        SDL_SetRenderDrawColor(rendu, 255, 220, 0, 255);
        for (int j = 0; j < i; j++) {
            SDL_Rect bloc = {
                zone_barre.x + j * (largeur_bloc + marge),
                zone_barre.y, largeur_bloc, zone_barre.h
            };
            SDL_RenderFillRect(rendu, &bloc);
        }

        SDL_RenderPresent(rendu);
        SDL_Delay(20);
    }

    SDL_DestroyTexture(fond);
    SDL_DestroyTexture(texture_texte);
    TTF_CloseFont(police);
    TTF_CloseFont(police_grasse);
}

// === Menu Principal ===
Page afficher_menu(SDL_Renderer* rendu) {
    Mix_Music* musique = Mix_LoadMUS("ressource/musique/menu.wav");
    if (musique) Mix_PlayMusic(musique, -1);

    SDL_Texture* fond = IMG_LoadTexture(rendu, "ressource/image/Menu.png");
    SDL_Texture* cadre_titre = IMG_LoadTexture(rendu, "ressource/image/CadreTitre.png");
    SDL_Texture* cadre_bouton = IMG_LoadTexture(rendu, "ressource/image/fond_texte.png");

    TTF_Font* police = TTF_OpenFont("ressource/langue/police/arial.ttf", 40);
    SDL_Color noir = {0, 0, 0, 255};

    SDL_Rect zone_titre = {262, 0, 500, 250};
    SDL_Rect boutons[3] = {
        {370, 160, 280, 190},
        {370, 280, 280, 190},
        {370, 400, 280, 190}
    };
    const char* textes[] = {"Jouer", "Options", "Quitter"};

    SDL_RenderClear(rendu);
    SDL_RenderCopy(rendu, fond, NULL, NULL);
    SDL_RenderCopy(rendu, cadre_titre, NULL, &zone_titre);

    for (int i = 0; i < 3; i++) {
        SDL_RenderCopy(rendu, cadre_bouton, NULL, &boutons[i]);
        SDL_Surface* surf = TTF_RenderUTF8_Blended(police, textes[i], noir);
        SDL_Texture* tex = SDL_CreateTextureFromSurface(rendu, surf);
        SDL_Rect txt = {
            boutons[i].x + (boutons[i].w - surf->w) / 2,
            boutons[i].y + (boutons[i].h - surf->h) / 2,
            surf->w, surf->h
        };
        SDL_RenderCopy(rendu, tex, NULL, &txt);
        SDL_FreeSurface(surf);
        SDL_DestroyTexture(tex);
    }

    SDL_RenderPresent(rendu);

    SDL_Event event;
    while (1) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) return PAGE_QUITTER;

            if (event.type == SDL_MOUSEBUTTONDOWN) {
                int x = event.button.x;
                int y = event.button.y;

                if (x >= boutons[0].x && x <= boutons[0].x + boutons[0].w &&
                    y >= boutons[0].y && y <= boutons[0].y + boutons[0].h) {
                    SDL_Log("Bouton Jouer cliqué - aucune action définie");
                }
                if (x >= boutons[1].x && x <= boutons[1].x + boutons[1].w &&
                    y >= boutons[1].y && y <= boutons[1].y + boutons[1].h) {
                    return PAGE_OPTIONS;
                }
                if (x >= boutons[2].x && x <= boutons[2].x + boutons[2].w &&
                    y >= boutons[2].y && y <= boutons[2].y + boutons[2].h) {
                    return PAGE_QUITTER;
                }
            }
        }
    }

    TTF_CloseFont(police);
    SDL_DestroyTexture(fond);
    SDL_DestroyTexture(cadre_titre);
    SDL_DestroyTexture(cadre_bouton);
    return PAGE_MENU;
}

// === Options ===
Page afficher_options(SDL_Renderer* rendu, Page page_prec) {
    SDL_Texture* fond = IMG_LoadTexture(rendu, "ressource/image/Menu.png");
    SDL_Texture* cadre_bouton = IMG_LoadTexture(rendu, "ressource/image/fond_texte.png");
    SDL_Texture* bouton_retour = IMG_LoadTexture(rendu, "ressource/image/Retour.png");

    const char* textes[] = {"Sauvegarde", "Langue", "Son"};
    SDL_Color noir = {0, 0, 0, 255};
    TTF_Font* police = TTF_OpenFont("ressource/langue/police/arial.ttf", 40);

    SDL_Rect boutons[3] = {
        {370, 160, 280, 190},
        {370, 280, 280, 190},
        {370, 400, 280, 190}
    };
    SDL_Rect retour_rect = {20, HAUTEUR_FENETRE - 100, 80, 80};

    SDL_Event event;
    while (1) {
        SDL_RenderClear(rendu);
        SDL_RenderCopy(rendu, fond, NULL, NULL);

        for (int i = 0; i < 3; i++) {
            SDL_RenderCopy(rendu, cadre_bouton, NULL, &boutons[i]);
            SDL_Surface* surf = TTF_RenderUTF8_Blended(police, textes[i], noir);
            SDL_Texture* tex = SDL_CreateTextureFromSurface(rendu, surf);
            SDL_Rect txt = {
                boutons[i].x + (boutons[i].w - surf->w) / 2,
                boutons[i].y + (boutons[i].h - surf->h) / 2,
                surf->w, surf->h
            };
            SDL_RenderCopy(rendu, tex, NULL, &txt);
            SDL_FreeSurface(surf);
            SDL_DestroyTexture(tex);
        }

        SDL_RenderCopy(rendu, bouton_retour, NULL, &retour_rect);
        SDL_RenderPresent(rendu);

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) return PAGE_QUITTER;
            if (event.type == SDL_MOUSEBUTTONDOWN) {
                int x = event.button.x, y = event.button.y;
                if (x >= retour_rect.x && x <= retour_rect.x + retour_rect.w &&
                    y >= retour_rect.y && y <= retour_rect.y + retour_rect.h)
                    return page_prec;
            }
        }
    }

    TTF_CloseFont(police);
    SDL_DestroyTexture(fond);
    SDL_DestroyTexture(cadre_bouton);
    SDL_DestroyTexture(bouton_retour);
    return PAGE_MENU;
}
